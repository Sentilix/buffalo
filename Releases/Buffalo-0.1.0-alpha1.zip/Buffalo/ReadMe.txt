
Buffalo buffing addon
---------------------

version 0.1.0-alpha1:
No UI whatsoever (beside the buff button).
Addon can BUFF for Priest, Mage (untested), Druid and Warlock (untested).
Assigned groups are hardcoded to 1,2,3 and 4.
Assigned buffs are assigned to bitmask 0x003. For a priest that is Fortitude and Spirit.
Addon only supports Raids for the moment.

